import React, {Component} from 'react';
import Location from '../components/Location';
import LocationService from '../services/location.service';

class ListLocation extends Component{
    constructor(props){
        super(props);
        this.state = {
            title: "Location",
            location: []
        }
    }

    componentWillMount(){
        console.log("Je suis la");
      }
    
      async componentDidMount(){
        let response = await LocationService.list();
        if(response.ok){
            // La réponse est de type 200
            let data = await response.json();
            console.log(data);
            this.setState({
                title: "Liste des utilisateurs",
                location : data.location
            });
        }
      }


    render(){
        return(
            <div className="container">
                <h1 style={{fontSize: 40, backgroundColor: "#037696", fontFamily: 'Palatino' }}>{this.state.title} </h1>
                {
                        this.state.location.map((item, index )=> {
                            return (
                                <Location key={index} data={item}/>
                            )
                        })
                    }
            </div>
        )
    }
}

export default ListLocation;