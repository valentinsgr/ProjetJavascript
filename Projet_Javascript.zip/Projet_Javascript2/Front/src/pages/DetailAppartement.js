import React, {Component} from 'react';
import AppartementService from "../services/appartement.service";
import {Link} from "react-router-dom";

class DetailAppartement extends Component {
    constructor(props) {
        super(props);
        this.state = {
            appartement_id: "",
            appartement_description: "",
            appartement_ville: "",
            appartement_categorie: "",
            appartement_personne: "",
            appartement_montant: ""
        }
    }

    async componentDidMount() {
        let id = this.props.match.params.id;
        console.log(id);
        let response = await AppartementService.details(id);
        console.log(response);
        if (response.ok) {
            //La réponse est de type 200
            let data = await response.json();
            console.log(data);
            this.setState({
                title: "Detail de la location",
                appartement_id: data.id,
                appartement_description: data.appartement.appartement_description,
                appartement_ville: data.appartement.appartement_ville,
                appartement_categorie: data.appartement.appartement_categorie,
                appartement_personne: data.appartement.appartement_nb_personne,
                appartement_montant: data.appartement.appartement_montant
            });
            console.log(data.id);
        }
    }

    render() {
        return (
            
            <div className="container">
                  <h1 style={{fontSize: 70, backgroundColor: "red", fontFamily: 'Palatino', textAlign:"center", color:"white"}}>{this.state.title} </h1>
                <div class="col-3 title-appartement">{this.state.appartement_description}</div>
                <div class="col-9 image-description">< img class="imgappart" src = " http://lyon-rose.staticlbi.com/original/images/biens/5/6af683c54e8053478228669aeb62304d/photo_import_99be3bd16ad90e917f597da009a91cef.jpg " /></div>
                <div class="col-6 informationappart">Situation: {this.state.appartement_ville}</div>
                <div class="col-6 informationappart">Type d'hébergement: {this.state.appartement_categorie}</div>
                <div class="col-6 informationappart">Nombre de personnes: {this.state.appartement_personne}</div>
                <div class="col-6 informationappart">Montant par nuit: {this.state.appartement_montant}</div>
                <div class="boutonreservation"><button className="btn btn-danger btnreservation">Réserver</button></div>
            
            </div>
        );
    }
}

export default DetailAppartement;

//this.props.match.params.monparam
