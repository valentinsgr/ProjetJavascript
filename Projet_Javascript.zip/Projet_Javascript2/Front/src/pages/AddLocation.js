import React, {Component} from 'react';
import Location from '../components/Location';
import LocationService from '../services/location.service';


class AddLocation extends Component {
    constructor(props){
        super(props);
        this.state = {
            title: "Location",
            location: []
        }
    }

    componentWillMount(){
        console.log("Je suis la");
      }
    
      async componentDidMount(){
        let response = await LocationService.list();
        if(response.ok){
            // La réponse est de type 200
            let data = await response.json();
            console.log(data);
            this.setState({
                title: "Liste des utilisateurs",
                location : data.location
            });
        }
      }
      
    render() {
        return (
            <div className="container">
            <form onSubmit={(e) => this.submit(e)}>
                <h1>Reserver une location</h1>
                <select name="jour" size="1">
                    
<option>01</option>
<option>02</option>
<option>03</option>
<option>04</option>
<option>05</option>
</select>
<select name="mois" size="1">
                    
<option>01</option>
<option>02</option>
<option>03</option>
<option>04</option>
<option>05</option>
<option>06</option>
<option>07</option>
<option>08</option>
<option>09</option>
<option>10</option>
<option>11</option>
<option>12</option>
<br></br>
</select>
                <button className="btn btn-primary">Réserver</button>
            </form>
            {
                this.state.success ? <p>{this.state.msgSuccess}</p> : null
            }
        </div>
        );
    }
}

export default AddLocation;

