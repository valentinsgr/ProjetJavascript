import React, {Component} from 'react';
import AppartementService from "../services/appartement.service";

class AddAppart extends Component {
    constructor(props) {
        super(props);
        this.state = {
            appartement_id: '',
            appartement_ville: '',
            appartement_categorie: '',
            appartement_nb_personne:'',
            appartement_montant: '',
            appartement_description:'',
            success: false,
            msgSuccess:'le message est enregistré avec succès'
        }
    }
    //on modifie les valeurs du msg success
    componentDidMount() {
        this.setState({
            title:"Proposer une location"
        })
    }

    handleChange(e) {
        this.setState({
            [e.target.id]: e.target.value
        });
    }

  async submit(e){
        //annuler l'evenement onclick
        e.preventDefault();
        this.setState({success: false})
        console.log("je submit");
        let body = {
            appartement_id: this.state.appartement_id,
            appartement_ville: this.state.appartement_ville,
            appartement_categorie: this.state.appartement_categorie,
            appartement_nb_personne: this.state.appartement_nb_personne,
            appartement_montant: this.state.appartement_montant,
            appartement_description: this.state.appartement_description,
        };
        let response  = await AppartementService.create(body);
        if (response.ok){
            this.setState({
                success: true,
                msgSuccess: "Location cree avec succès"
            });

         /*on retourne sur l'url precedent*/
            this.props.history.push('/appartement');
        }
    }
    render() {
        return (
            <div className="container">
                  <h1 style={{fontSize: 70, backgroundColor: "red", fontFamily: 'Palatino', textAlign:"center", color:"white"}}>{this.state.title} </h1>
                <form onSubmit={(e) => this.submit(e)}>
                    <div className="form-group">
                        <label>Code de location</label>
                        <input className="form-control" required id="appartement_id" type="text"
                               onChange={(e) => this.handleChange(e)}/>
                    </div>
                    <div className="form-group">
                        <label>Ville</label>
                        <input className="form-control" required id="appartement_ville" type="text"
                               onChange={(e) => this.handleChange(e)}/>
                    </div>
                    <div className="form-group">
                        <label>Categorie de la location (Exemple : Maison, appartement, studio) </label>
                        <input className="form-control" required id="appartement_categorie" type="text"
                               onChange={(e) => this.handleChange(e)}/>
                    </div>
                    <div className="form-group">
                        <label>Nombre de personne </label>
                        <input className="form-control" required id="appartement_nb_personne" type="text"
                               onChange={(e) => this.handleChange(e)}/>
                    </div>
                    <div className="form-group">
                        <label>Prix de la location (par nuit) </label>
                        <input className="form-control" required id="appartement_montant" type="text"
                               onChange={(e) => this.handleChange(e)}/>
                    </div>
                    <div className="form-group">
                        <label>Description</label>
                        <input className="form-control" required id="appartement_description" type="text"
                               onChange={(e) => this.handleChange(e)}/>
                    </div>
                    <button className="btn btn-primary">Ajouter</button>
                </form>
                {
                    this.state.success ? <p>{this.state.msgSuccess}</p> : null
                }
            </div>
        );
    }
}

export default AddAppart;

