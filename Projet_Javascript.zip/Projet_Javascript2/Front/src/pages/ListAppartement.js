import React, {Component} from 'react';
import User from '../components/User';
import Appartement from '../components/Appartement';
import UserService from '../services/user.service';
import AppartementService from '../services/appartement.service';


class ListeAppartement extends Component{
    constructor(props){
        super(props);
        this.state = {
            title: "Liste Appartement",
            appartement: []
        }
    }

    componentWillMount(){
        console.log("Je suis la");
      }
    
      async componentDidMount(){
        let response = await AppartementService.list();
        if(response.ok){
            // La réponse est de type 200
            let data = await response.json();
            console.log(data);
            this.setState({
                title: "Choix de la location",
                appartement : data.appartement
            });
        }
      }


    render(){
        return(
            <div className="container">
                 <h1 style={{fontSize: 70, backgroundColor: "red", fontFamily: 'Palatino', textAlign:"center", color:"white"}}>{this.state.title} </h1>
                {
                        this.state.appartement.map((item, index )=> {
                            return (
                                <Appartement key={index} data={item}/>
                            )
                        })
                    }
            </div>
        )
    }
}

export default ListeAppartement;