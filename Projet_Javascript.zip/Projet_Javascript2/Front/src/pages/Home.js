import React, {Component} from 'react';
import User from '../components/User';
import UserService from '../services/user.service';



class Home extends Component{
    constructor(props){
        super(props);
        this.state = {
            title: "Seloger2.0",
            users: []
        }
    }

    componentWillMount(){
        console.log("Je suis la");
      }
    
      async componentDidMount(){
        let response = await UserService.list();
        if(response.ok){
            // La réponse est de type 200
            let data = await response.json();
            console.log(data);
            this.setState({
                title: "Se loger 2.0",
                users : data.user
            });
        }
      }


    render(){
        return(
            <div className="container">
                <h1 style={{fontSize: 70, backgroundColor: "red", fontFamily: 'Palatino', textAlign:"center", color:"white"}}>{this.state.title} </h1>
               <div style={{ textAlign:"center"}}><img src="https://www.sunlocation.com/images/theme/location-vacances-sud.jpg    "></img></div>
                        <div style={{ textAlign:"center"}}><p>Bienvenue sur le site SeLoger2.0</p>
                        <p>Connecter vous pour poursuivre sur le site, si vous n'avez pas de compte inscrivez</p></div>
                    
            </div>
        )
    }
}

export default Home;