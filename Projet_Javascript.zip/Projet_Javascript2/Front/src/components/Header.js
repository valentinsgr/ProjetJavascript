import React, { Component } from 'react';
import {Link} from 'react-router-dom';
class Header extends Component{
    constructor(props){
        super(props);
    }

    handleChange(e){
      this.setState({
          [e.target.id] : e.target.value,
      })
      console.log(this.Success)
  }
  async submit(e){
    e.preventDefault();
    localStorage.removeItem('user');
    window.location.replace('/login');
    };

    render(){
        return(
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand" href="#">SeLoger</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="nav-item nav-link active" href="/appartement">Home <span class="sr-only">(current)</span></a>
              <a class="nav-item nav-link" href="/addAppart">Proposer un appartement</a>
              <a class="nav-item nav-link" href="/user">Liste des Utilisateurs</a>
              
            </div>
          </div>
          {
            ('user' in localStorage) ? <ul className="navbar-nav"><li className="nav-item"></li></ul> : <ul className="navbar-nav"><li className="nav-item"> <Link className="nav-link" to ={'/signup'}>Inscription </Link> </li> </ul>
          }
          {
            ('user' in localStorage) ? <ul className="navbar-nav"><li className="nav-item"> <Link id='deconnexion' className="nav-link" onClick={(e) => this.submit(e)} to ={'/login'}>Déconnexion</Link> </li></ul> : <ul className="navbar-nav"><li className="nav-item"> <Link className="nav-link" to ={'/login'}>Connexion </Link> </li> </ul>
          }
        </nav>

            )
    }
}

export default Header;
