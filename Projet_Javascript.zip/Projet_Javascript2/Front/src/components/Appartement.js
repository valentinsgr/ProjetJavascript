import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import '../css/Appartement.css';
import '../css/Footer.css';

class Appartement extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        console.log(this.props);
    }

    async submit(e){
        e.preventDefault();
        window.location.replace(`/appartement/`);
        };

    render() {
        return (
                <Link to={`/appartement/${this.props.data._id}`}><div class="col-6 propositionappart">
                <div>< img class="imgappart" src = " http://lyon-rose.staticlbi.com/original/images/biens/5/6af683c54e8053478228669aeb62304d/photo_import_99be3bd16ad90e917f597da009a91cef.jpg " /></div>
                <div>Ville: {this.props.data.appartement_ville}</div>
                <div>Nombre de personnes: {this.props.data.appartement_nb_personne}</div>
                <div>Prix(par nuit): {this.props.data.appartement_montant}€</div>
                </div>
                </Link>
        )
    }
}

export default Appartement;