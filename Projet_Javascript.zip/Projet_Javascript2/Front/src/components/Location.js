import React, { Component } from 'react';
import {Link} from 'react-router-dom';
import LocationService from '../services/location.service';

class Location extends Component{
    constructor(props){
        super(props);
    }

    componentDidMount(){
        console.log(this.props)
    }

    render(){
        return(
            <div>
            <div>Id : {this.props.data._id}</div>
            <div>Date de debut de la réservation: {this.props.data.location_date_debut}</div>
            <div>Date de fin de la réservation: {this.props.data.location_date_fin}</div>
            <br></br>
            </div>
        )
    }
}

export default Location;

