import React, { Component } from 'react';
import {Link} from 'react-router-dom';

class User extends Component{
    constructor(props){
        super(props);
    }

    componentDidMount(){
        console.log(this.props)
    }

    render(){
        return(
            <Link to={`/user/${this.props.data._id}`}><div class="col-3 propositionappart">
            <div>< img class="imgappart" src = " https://upload.wikimedia.org/wikipedia/commons/5/5f/User_with_smile.svg " /></div>
            <div>Nom: {this.props.data.nom}</div>
            <div>Email: {this.props.data.email}</div>
            </div>
            </Link>
        )
    }
}

export default User;

