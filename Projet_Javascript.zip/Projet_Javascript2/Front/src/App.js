import React, { Component } from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
// import logo from './logo.svg';
import './App.css';
import Home from './pages/Home';
import Header from './components/Header';
import Footer from './components/Footer';
import Login from './pages/Login';
import Signup from './pages/signup';
import ListAppartement from './pages/ListAppartement';
import DetailAppartement from './pages/DetailAppartement';
import AddAppart from './pages/AddAppart'; 
import ListUser from './pages/ListUsers';
import ListLocation from './pages/ListLocation';
import AddLocation from './pages/AddLocation';



class App extends Component {
  constructor(props){
    super(props);
  }

  componentWillMount(){
    console.log("Component will mount");
  }

  componentDidMount(){
    console.log("Component did mount");
    console.log(localStorage.getItem('user'));
    if("user" in localStorage){
      console.log('yes');
   } else {
      console.log('no');
   }
  }

  render() {
    return (
      <BrowserRouter>
      <Header />
        <Route path="/" exact component={Home} />
        <Route path="/login" exact component={Login} />
        <Route path="/signup" exact component={Signup} />
        <Route path="/appartement" exact component={ListAppartement} />
        <Route path="/user" exact component={ListUser} />
        <Route path="/AddAppart" exact component={AddAppart} />
        <Route path="/appartement/:id" exact component={DetailAppartement} />
        {/* <Route path="/location" exact component={ListLocation} /> */}
        <Route path="/Ajoutlocation" exact component={AddLocation} />
        {/* <Routh path="/location/:id/:user" exact component ={Location}/> */}
        {/* <Route path="/posts/:id" exact component={DetailsPost} />
        <Route path="/add-post" exact component={AddPost} /> */}
        <Footer />
      </BrowserRouter>
    );
  }
}

export default App;
