const baseUrl = "http://localhost:3001";

class AppartementService{
    static async list(){
        let init = {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        };
        let call = await fetch(`${baseUrl}/appartement/`, init);
        return call;
    }

    static async details(id){
        let init = {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        };
        let call = await fetch(`${baseUrl}/appartement/${id}`, init);
        return call;
    }

    static async create(body){
        let init = {
            method: "POST",
            headers:{
                "Content-Type": "application/json"
            },
            body: JSON.stringify(body)
        };
        let call = await fetch(`${baseUrl}/appartement/`, init);
        return call;
    }

   
}

export default AppartementService;