import {Router} from 'express';
import CommentsController from '../controllers/comments.controller.js';
import PostController from '../controllers/posts.controller.js';
import UserController from '../controllers/user.controller.js';
import AppartementController from '../controllers/appartement.contoller.js';
import LocationController from '../controllers/location.controller.js';
const router = Router();

// router.get('/hello', function(req, res){
// 	console.log('Hello');
// 	res.send('Hello');
// });

// //Posts
// router.get("/user:id",UserController.detail);
// router.post('/posts',PostController.create);
// router.get('/posts/:id',PostController.details);
//router.post('/location/:id/:user',LocationController.addAppartement);
router.post('/user',UserController.create);
router.get('/users',UserController.list);
router.get('/user/:id',UserController.details);
router.get('/appartement',AppartementController.list);
router.post('/appartement',AppartementController.create);
router.get('/appartement/:id',AppartementController.details);
router.get('/location',LocationController.list);
router.post('/location/:id/:user',LocationController.create);
router.post('/appartement/:id/:idlocation', AppartementController.addReservation);

// //delete posts
router.delete('/user/:id',UserController.delete);
router.delete('/appartement/:id',AppartementController.delete);
router.get('/location',LocationController.list);

// //update posts
// router.put('/posts/:id',PostController.update);
// //Users

// //Comments
// router.get('/comments/:id',CommentsController.details);

router.post('/auth', UserController.auth);

export default router;
