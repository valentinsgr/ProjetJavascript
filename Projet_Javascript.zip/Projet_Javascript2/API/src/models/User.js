import {Schema, model} from 'mongoose';

const userSchema = new Schema({

	user_id: {
		type: String,
		required: false
	},
	nom: {
		type: String,
		required: true
	},
	password: {
		type: String,
		required: true,
	},
	email: {
		type: String,
		require: true
	},
	typeUtilisateur: {
		type: String,
		require: false
	},
	user_location: {
		type: Schema.Types.ObjectId,
		ref:"Appartement"
	}

});

const User = model('User', userSchema);

export default User;