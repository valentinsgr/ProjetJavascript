import {Schema, model} from 'mongoose';

const locationSchema = new Schema({

	location_id: {
		type: String,
		required: true,
	},
	location_date_debut: {
		type: String,
		required: true,
	},
	location_date_fin: {
		type: String,
		required: true,
	},
	location_id_user: {
		type: Schema.Types.ObjectId,
		ref:"User"
     },
    location_id_appartement: {
        type: Schema.Types.ObjectId,
		ref:"Appartement"
    }

});

const Location = model('Location', locationSchema);

export default Location;