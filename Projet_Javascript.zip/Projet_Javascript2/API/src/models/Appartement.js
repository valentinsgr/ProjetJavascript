import {Schema, model} from 'mongoose';

const appartementSchema = new Schema({

	appartement_id: {
		type: String,
		required: true,
	},
	appartement_ville: {
		type: String,
		required: true,
	},
	appartement_categorie: {
		type: String,
		required: true,
	},
	appartement_nb_personne: {
		type: Number,
		require: true,
	},
	appartement_montant: {
		type: Number,
		require: true,
	},
	appartement_description: {
		type: String,
		require: true,
	},
	appartement_reservation: [{
		type: Schema.Types.ObjectId,
		ref:"Location",
	}]

});

const Appartement = model('Appartement', appartementSchema);

export default Appartement;