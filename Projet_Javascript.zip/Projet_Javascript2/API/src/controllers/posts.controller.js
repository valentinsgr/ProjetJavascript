import Post from '../models/Post';

class PostController{

	static async list(request, response){

		/*let posts = [
		{
			id: 1,
			title: "Mon title",
			content: "Mon content",
		},
		{
			id: 2,
			title: "Mon title",
			content: "Mon content",
		},
		{
			id: 3,
			title: "Mon title",
			content: "Mon content",
		},
		];*/

		let status = 200;
		let body = {};

		/**
		 *Plusieurs méthodes :
		 *Post.find({date: '....'}) //listener tous les posts
		 *Post.findOne{slug: "mon-titre"});
		 	* Post.findId("123456");
		 */

		try{
			let posts = await Post.find();
			body = {posts, 'message': 'List posts'};
		}catch (error){
			status= 500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
		//return response.status(200).json(posts);
	}

	static async create(request, response){
		let status = 200;
		let body = {};

		console.log(request.body);

		try{
			let posts=await Post.create({
				title: request.body.montitre,
				content: request.body.moncontenu
			});

			body = {post, 'message': 'Post created'};
		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	static async details(request, response){
		let status = 200;
		let body = {};

		try{
			let id = request.params.id;
			let posts = await Post.findById(id);
			body = { posts,'message': "ok ca amrche"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}
	/**delete post
	* @param {Request} request
	* @param {Response} response
	*/

	static async delete(request, response){
		let status = 200;
		let body = {};

		try{
			let id = request.params.id;
			await Post.deleteOne(id);
			body = { posts,'message': "ok ca amrche"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	/**update post
	* @param {Request} request
	* @param {Response} response
	*/

	static async update(request, response){
		let status = 200;
		let body = {};

		try{
			let id = request.params.id;

			//delete req.body.password;

			let post = await Post.findById(id);
			await post.update(request.body);
			body = {posts,'message': "Details"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}
}

export default PostController;