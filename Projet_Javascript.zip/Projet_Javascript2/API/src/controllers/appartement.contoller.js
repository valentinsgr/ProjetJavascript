import Appartement from '../models/Appartement';
import Location from '../models/Location'; 

class AppartementController{

	static async create(request, response){

		let status = 200;
		let body = {};

		try{
			let appartement = await Appartement.create({
				appartement_id: request.body.appartement_id,
				appartement_ville: request.body.appartement_ville,
				appartement_categorie: request.body.appartement_categorie,
				appartement_nb_personne: request.body.appartement_nb_personne,
				appartement_montant: request.body.appartement_montant,
				appartement_description: request.body.appartement_description,
                appartement_reservation: request.body.appartement_reservation
            });

			body = {appartement, 'message':'Appartement created'};
		}catch (error){
			status= 500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	static async details(request, response){
		let status = 200;
		let body = {};

		try{
			let id = request.params.id;
			let appartement = await Appartement.findById(id);
			body = { appartement,'message': "ok detail marche"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	/**delete post
	* @param {Request} request
	* @param {Response} response
	*/

	static async delete(request, response){
		let status = 200;
		let body = {};

		try{
			let id = request.params.appartement;
			let appartement = await Appartement.deleteOne(id);
			body = { appartement,'message': "ok delate fonctionne"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	static async addReservation(request, response){
		let status = 200;
		let body ={};
		try{
			let id = request.params.id;
			let idlocation= request.params.idlocation;	
			let idAppartement = await Appartement.findById(id);
			console.log(idlocation);
			let idLoca = await Location.findById(idlocation);
			//console.log(idAppartement);
			console.log(idLoca);
			/*let appartement = await Appartement.push({
				appartement_reservation: idLoca
			});
			body = {appartement, 'message': 'Location added'};*/
		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	/**update post
	* @param {Request} request
	* @param {Response} response
	*/

	static async update(request, response){
		let status = 200;
		let body = {};

		try{
			let id = request.params.id;

			//delete req.body.password;

			let appartement = await Appartement.findById(id);
			await appartement.update(request.body);
			body = {appartement,'message': "Details"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	static async list(request, response){

		let status = 200;
		let body = {};

		/**
		 *Plusieurs méthodes :
		 *Post.find({date: '....'}) //listener tous les posts
		 *Post.findOne{slug: "mon-titre"});
		 	* Post.findId("123456");
		 */

		try{
			let appartement = await Appartement.find();
			body = {appartement, 'message': 'List Appartement'};
		}catch (error){
			status= 500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

}

export default AppartementController;