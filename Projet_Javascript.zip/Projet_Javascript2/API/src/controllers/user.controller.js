import User from '../models/User';

class UserController{

	static async create(request, response){

		let status = 200;
		let body = {};

		try{
			let user = await User.create({
				user_id: request.body.user_id,
				nom: request.body.nom,
				password: request.body.password,
				email: request.body.email,
				typeUtilisateur: request.body.typeUtilisateur
			});

			body = {user, 'message':'User created'};
		}catch (error){
			status= 500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	static async details(request, response){
		let status = 200;
		let body = {};

		try{
			let id = request.params.id;
			let user = await User.findById(id);
			body = { user,'message': "ok detail marche"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	/**delete post
	* @param {Request} request
	* @param {Response} response
	*/

	static async delete(request, response){
		let status = 200;
		let body = {};

		try{
			let id = request.params.user_id;
			let user = await User.deleteOne(id);
			body = { user,'message': "ok delate fonctionne"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	/**update post
	* @param {Request} request
	* @param {Response} response
	*/

	static async update(request, response){
		let status = 200;
		let body = {};

		try{
			let id = request.params.id;

			//delete req.body.password;

			let user = await User.findById(id);
			await user.update(request.body);
			body = {user,'message': "Details"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	static async list(request, response){

		let status = 200;
		let body = {};

		/**
		 *Plusieurs méthodes :
		 *Post.find({date: '....'}) //listener tous les posts
		 *Post.findOne{slug: "mon-titre"});
		 	* Post.findId("123456");
		 */

		try{
			let user = await User.find();
			body = {user, 'message': 'List USER'};
		}catch (error){
			status= 500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	static async auth(request,response){
        let status = 200;
		let body = {};
        try {
            if(await User.findOne({email: request.body.email, password: request.body.password})){
				let user = await User.findOne({email: request.body.email, password: request.body.password});
				
                body = {user, 'message': 'connected'};
            }else{
                body = {'message': 'Email ou password incorrect'};
            }
        } catch (error) {
            status = 500;
            body = {'message': error.message}
    }
    return response.status(status).json(body);
    } 

}

export default UserController;