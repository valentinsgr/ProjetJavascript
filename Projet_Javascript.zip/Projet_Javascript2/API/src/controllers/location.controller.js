import Location from '../models/Location';
import Appartement from '../models/Appartement';
import User from '../models/User';

class LocationController{
    
    static async create(request, response){

		let status = 200;
		let body = {};

		try{
            let userid=request.params.user;
            console.log(userid);
            let id=request.params.id;
            // console.log(id);
             let idAppartement = await Appartement.findById(id);
             let iduser = await User.findById(userid);
             //console.log(idAppartement);
             let location_id_appartement = idAppartement.id;
             let location_id_user = iduser.id;
             console.log(location_id_appartement);
			let location = await Location.create({
				location_id: request.body.location_id,
				location_date_debut: request.body.location_date_debut,
                location_date_fin: request.body.location_date_fin,
                location_id_user: location_id_user,
				location_id_appartement: location_id_appartement
            });

			body = {location, 'message':'Appartement created'};
		}catch (error){
			status= 500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
    }
    
    static async addAppartement(request, response){
        let status = 200;
        let body = {};
        try{
            let user=request.params.user;
            let id=request.params.id;
            console.log(id);
            console.log(user);  

        }catch (error){
			status= 500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
    }

	static async details(request, response){
		let status = 200;
		let body = {};

		try{
			let id = request.params.id;
			let location = await Location.findById(id);
			body = { location,'message': "ok detail marche"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

	// /**delete post
	// * @param {Request} request
	// * @param {Response} response
	// */

	// static async delete(request, response){
	// 	let status = 200;
	// 	let body = {};

	// 	try{
	// 		let id = request.params.appartement;
	// 		let appartement = await Appartement.deleteOne(id);
	// 		body = { appartement,'message': "ok delate fonctionne"};

	// 	}catch (error){
	// 		status =500;
	// 		body = { 'message': error.message};
	// 	}
	// 	return response.status(status).json(body);
	// }

	// /**update post
	// * @param {Request} request
	// * @param {Response} response
	// */

	// static async update(request, response){
	// 	let status = 200;
	// 	let body = {};

	// 	try{
	// 		let id = request.params.id;

	// 		//delete req.body.password;

	// 		let appartement = await Appartement.findById(id);
	// 		await appartement.update(request.body);
	// 		body = {appartement,'message': "Details"};

	// 	}catch (error){
	// 		status =500;
	// 		body = { 'message': error.message};
	// 	}
	// 	return response.status(status).json(body);
	// }

	static async list(request, response){

		let status = 200;
		let body = {};

		/**
		 *Plusieurs méthodes :
		 *Post.find({date: '....'}) //listener tous les posts
		 *Post.findOne{slug: "mon-titre"});
		 	* Post.findId("123456");
		 */

		try{
			let location = await Location.find();
			body = {location, 'message': 'List Appartement'};
		}catch (error){
			status= 500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}

}

export default LocationController;