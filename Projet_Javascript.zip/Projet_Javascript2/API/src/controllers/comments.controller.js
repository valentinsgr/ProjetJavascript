import Post from '../models/Post';

class CommentsController{

	static async list(request, response){

		let status = 200;
		let body = {};

		try{
			let comment = await Comment.create({
				title: request.body.title,
				content: request.body.content,
				post_id: request.body.post_id
			});

			body = {comment, 'message':'Comment created'};
		}catch (error){
			status= 500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
		//return response.status(200).json(posts);
	}
	static async details(request, response){
		let status = 200;
		let body = {};

		try{
			let comment = await Comment.findById(request.params.id).populate('post_id');
			body = {comment,'message': "Comment details"};

		}catch (error){
			status =500;
			body = { 'message': error.message};
		}
		return response.status(status).json(body);
	}
}

export default CommentsController;